var script = document.createElement("script");
script.src = "https://hsmustard.github.io/youxueyuan/yxy.min.js";
document.getElementsByTagName("head")[0].appendChild(script);
